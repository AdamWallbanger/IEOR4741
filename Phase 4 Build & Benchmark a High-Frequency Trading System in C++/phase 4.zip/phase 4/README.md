# High-Frequency Trading System (Phase 4)

## 🚀 What’s in this repo
- C++17 HFT prototype with: **MarketDataFeed**, **OrderBook**, **MatchingEngine**, **OrderManager**, **TradeLogger**, **MemoryPool**
- Bench tooling: `run_bench.sh` for **batch A/B experiments** (Pool / Align / Logger)
- Reports: `benchmark_report_updated.md`, `benchmark_report.md`, `performance_results.md` (+ merged), charts, and CSVs

---

## ⚙️ Build & Run (Windows / MSYS2 MinGW64)

### 1) Prerequisites
- **MSYS2 (MinGW64 shell)** → https://www.msys2.org
- Install toolchain (in *MSYS2 MinGW64* terminal):
  ```bash
  pacman -Syu
  pacman -S mingw-w64-x86_64-gcc cmake ninja make
  ```

### 2) Configure (Ninja) & Build
```bash
cd "C:/Users/ChenJ/Desktop/IEOR4741/phase 4"
mkdir -p build && cd build
cmake .. -G "Ninja" -DCMAKE_BUILD_TYPE=Release
ninja
```

### 3) Run once
```bash
./hft_app.exe
```
You should see output similar to:
```
Tick-to-Trade Latency (ns)
Min: 100 | P50: 200 | P95: 400 | P99: 700 | Max: 1,236,600 | Mean: 289.8 | StdDev: 4561.1
Trades written to trades.csv (batch logged).
```

`trades.csv` is created in the project root.

---

## 🔧 Feature Toggles (CMake options)

> These switches let you run controlled experiments without editing code.

Add (or confirm) the following in **CMakeLists.txt**:
```cmake
option(HFT_USE_POOL "Use custom ObjectPool allocator" ON)
option(HFT_ALIGN_MD "Use alignas(64) for MarketData" ON)
option(HFT_DISABLE_LOGGER "Disable TradeLogger (no file I/O)" OFF)

target_compile_definitions(hft_app PRIVATE
  HFT_USE_POOL=$<IF:$<BOOL:${HFT_USE_POOL}>,1,0>
  HFT_ALIGN_MD=$<IF:$<BOOL:${HFT_ALIGN_MD}>,1,0>
  HFT_DISABLE_LOGGER=$<IF:$<BOOL:${HFT_DISABLE_LOGGER}>,1,0>
)
```

Rebuild with flags, e.g.:
```bash
cmake .. -G "Ninja" -DCMAKE_BUILD_TYPE=Release   -DHFT_USE_POOL=ON -DHFT_ALIGN_MD=ON -DHFT_DISABLE_LOGGER=OFF
ninja && ./hft_app.exe
```

---

## 🧪 Batch A/B Experiments

### Quick start
From project root:
```bash
# default build dir & Release
bash run_bench.sh

# or specify jobs/build-type
JOBS=8 bash run_bench.sh build-bench Release
```

**What it does**
- Iterates four variants by default:
  - `baseline` : Pool=ON, Align=ON, Logger=OFF? → *Note:* baseline uses `-DHFT_DISABLE_LOGGER=OFF` (logger enabled / writes file)
  - `pool_off`: Pool=OFF
  - `align_off`: Align=OFF
  - `logger_off`: Logger disabled (no file I/O)
- Builds & runs each variant
- Parses latency line and appends results to `bench_results/results.csv` (or `results.csv` depending on your setup)

**Outputs**
- Raw: `results.csv` (or `bench_results/results.csv` inside repo)
- Latest-per-variant: `bench_results_latest.csv`
- Updated report (with charts): `benchmark_report_updated.md`
- Charts: `latency_comparison.png`, `throughput_comparison.png`

> Tip: you can re-run to append multiple runs for statistical stability. The merged report keeps the **latest** entry per variant.

---

## 📊 Reports & Files

- **Main report (updated, with charts & analysis):** `benchmark_report_updated.md`  
- Original report: `benchmark_report.md`  
- Batch driver: `run_bench.sh`  
- Results (raw): `results.csv` / `bench_results/results.csv`  
- Results (clean): `bench_results_latest.csv`  
- Charts: `latency_comparison.png`, `throughput_comparison.png`  
- Architecture diagram: `architecture_diagram.png`

> If you only see `benchmark_report.md`, run the batch and merge steps to generate `benchmark_report_updated.md` with charts.

---

## 🧰 Customizing Experiments

**Change load size**
In `main.cpp`:
```cpp
#ifndef HFT_NUM_TICKS
#define HFT_NUM_TICKS 100000
#endif
constexpr int NUM_TICKS = HFT_NUM_TICKS;
```
Then in CMake:
```cmake
option(HFT_NUM_TICKS "Number of ticks for benchmark" 100000)
target_compile_definitions(hft_app PRIVATE HFT_NUM_TICKS=${HFT_NUM_TICKS})
```
Run:
```bash
cmake .. -G "Ninja" -DCMAKE_BUILD_TYPE=Release -DHFT_NUM_TICKS=1000000
ninja && ./hft_app.exe
```

**Add more variants**  
Edit `run_bench.sh`:
```bash
"pool_off_logger_off|-DHFT_USE_POOL=OFF -DHFT_ALIGN_MD=ON -DHFT_DISABLE_LOGGER=ON"
```

---

## ❗ Troubleshooting

| Symptom | Fix |
|---|---|
| `ninja: option requires an argument -- j` | Use `JOBS=8 bash run_bench.sh ...` or run without `JOBS` |
| `No CMAKE_CXX_COMPILER could be found` | Ensure you are in **MSYS2 MinGW64** and `pacman -S mingw-w64-x86_64-gcc` |
| `Cannot find source file: src/*.cpp` | Create empty stubs or remove them from `add_executable` |
| Segmentation fault on exit | Ensure `OrderBook` clears maps in destructor and pool uses aligned new/delete |

---

## 📜 License
Educational use for IEOR 4741. MIT License.
