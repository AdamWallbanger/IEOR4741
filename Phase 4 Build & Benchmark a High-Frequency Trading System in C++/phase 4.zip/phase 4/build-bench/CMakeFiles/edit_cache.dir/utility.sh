set -e

cd "/c/Users/ChenJ/Desktop/IEOR4741/phase 4/build-bench"
/usr/bin/ccmake.exe -S$(CMAKE_SOURCE_DIR) -B$(CMAKE_BINARY_DIR)
