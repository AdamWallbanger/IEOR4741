#pragma once
#include <string>
#include <chrono>
#include <random>
#include <vector>
#include <cstdint>

// Toggle: HFT_ALIGN_MD (default ON)
// 1 -> struct MarketData is cache-line aligned (alignas(64))
// 0 -> no special alignment (useful for A/B tests)
#ifndef HFT_ALIGN_MD
#define HFT_ALIGN_MD 1
#endif

#if HFT_ALIGN_MD
struct alignas(64) MarketData {
#else
struct MarketData {
#endif
    std::string symbol;
    double bid_price;
    double ask_price;
    std::chrono::high_resolution_clock::time_point timestamp;
};

// Simple deterministic tick generator for microbenchmarks
class MarketDataFeedSimulator {
public:
    MarketDataFeedSimulator(std::string sym, double mid=100.0, double spread=0.01, uint64_t seed=42)
        : m_sym(std::move(sym)), m_mid(mid), m_spread(spread), m_rng(seed), m_noise(0.0, 0.05) {}

    MarketData next() {
        double drift = m_noise(m_rng);
        m_mid += drift;
        MarketData md;
        md.symbol = m_sym;
        md.bid_price = m_mid - m_spread * 0.5;
        md.ask_price = m_mid + m_spread * 0.5;
        md.timestamp = std::chrono::high_resolution_clock::now();
        return md;
    }

private:
    std::string m_sym;
    double m_mid;
    double m_spread;
    std::mt19937_64 m_rng;
    std::normal_distribution<double> m_noise;
};
