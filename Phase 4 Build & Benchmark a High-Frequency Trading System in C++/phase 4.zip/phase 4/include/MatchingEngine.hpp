#pragma once
#include <vector>
#include <chrono>
#include "OrderBook.hpp"

struct Trade {
    int64_t trade_id;
    std::string symbol;
    double price;
    int quantity;
    std::chrono::high_resolution_clock::time_point ts_recv;
    std::chrono::high_resolution_clock::time_point ts_trade;
};

template <typename PriceT, typename OrderIdT, std::size_t PoolSize = (1<<16)>
class MatchingEngine {
public:
    using Book = OrderBook<PriceT, OrderIdT, PoolSize>;
    using OrderT = typename Book::OrderT;

    explicit MatchingEngine(Book& book) : m_book(book) {}

    // Match top-of-book repeatedly while crossed.
    // Returns trades (batch) generated.
    std::vector<Trade> match(const std::chrono::high_resolution_clock::time_point& tick_ts) {
        std::vector<Trade> trades;
        auto* bid = m_book.best_bid();
        auto* ask = m_book.best_ask();
        while (bid && ask && (bid->price >= ask->price) && bid->quantity > 0 && ask->quantity > 0) {
            int qty = std::min(bid->quantity, ask->quantity);
            double px = (ask->price + bid->price) * 0.5; // midpoint execution for demo
            auto now = std::chrono::high_resolution_clock::now();
            Trade t{++m_trade_seq, bid->symbol, px, qty, tick_ts, now};
            trades.push_back(t);
            bid->quantity -= qty;
            ask->quantity -= qty;
            if (bid->quantity <= 0) m_book.pop_best_bid_if_empty();
            if (ask->quantity <= 0) m_book.pop_best_ask_if_empty();
            bid = m_book.best_bid();
            ask = m_book.best_ask();
        }
        return trades;
    }

private:
    Book& m_book;
    int64_t m_trade_seq{0};
};
