#pragma once
#include <cstddef>
#include <new>
#include <vector>
#include <cassert>
#include <memory>
#include <type_traits>
#include <mutex>

// A small fixed-size pool for objects of T.
// Thread-safety: protected by a simple mutex (sufficient for single-thread benchmarks).
// Allocation policy:
//  - Pre-allocates BlockCount chunks of aligned raw storage for T.
//  - allocate(): placement-new into a free chunk; if exhausted, falls back to heap (::new T).
//  - deallocate(): calls ~T, then returns chunk to freelist (if from pool), otherwise ::operator delete for heap-fallback.
template <typename T, std::size_t BlockCount = (1u << 16)>
class ObjectPool {
public:
    ObjectPool() {
        m_storage.reserve(BlockCount);
        m_free.reserve(BlockCount);
        for (std::size_t i = 0; i < BlockCount; ++i) {
            // allocate aligned raw memory for T storage
            auto* mem = static_cast<TStorage*>(
                ::operator new(sizeof(TStorage), std::align_val_t(alignof(T)))
            );
            m_storage.push_back(mem);
            m_free.push_back(mem);
        }
    }

    ~ObjectPool() {
        // free raw memory with matching aligned delete
        for (auto* p : m_storage) {
            ::operator delete(p, std::align_val_t(alignof(T)));
        }
    }

    template <typename... Args>
    T* allocate(Args&&... args) {
        std::lock_guard<std::mutex> g(m_mtx);
        if (m_free.empty()) {
            return ::new T(std::forward<Args>(args)...); // heap fallback when pool exhausted
        }
        auto* storage = m_free.back();
        m_free.pop_back();
        return ::new (storage) T(std::forward<Args>(args)...);
    }

    void deallocate(T* obj) {
        if (!obj) return;
        obj->~T();
        void* raw = static_cast<void*>(obj);
        std::lock_guard<std::mutex> g(m_mtx);
        if (!owns(raw)) {
            ::operator delete(raw);
            return;
        }
        m_free.push_back(static_cast<TStorage*>(raw));
    }

private:
    using TStorage = typename std::aligned_storage<sizeof(T), alignof(T)>::type;

    bool owns(void* p) const {
        // Linear scan is acceptable for demo scale. Could be upgraded to unordered_set for O(1).
        for (auto* q : m_storage) if (q == p) return true;
        return false;
    }

    std::vector<TStorage*> m_storage;
    std::vector<TStorage*> m_free;
    mutable std::mutex m_mtx;
};

// Custom deleter to return objects to pool when using unique_ptr
template <typename T, std::size_t N>
struct PoolDeleter {
    ObjectPool<T, N>* pool{};
    void operator()(T* p) const noexcept {
        if (pool) pool->deallocate(p);
        else delete p;
    }
};
