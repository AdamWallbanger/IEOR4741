#pragma once
#include <map>
#include <memory>
#include <string>
#include <utility>
#include <cassert>

#include "Order.hpp"

// Toggle (can be overridden by compiler definitions)
#ifndef HFT_USE_POOL
#define HFT_USE_POOL 1
#endif

// IMPORTANT: include MemoryPool at global scope, NOT inside the class.
// Including it inside the class body corrupts the translation unit and breaks <vector>/<mutex> headers.
#if HFT_USE_POOL
#include "MemoryPool.hpp"
#endif

template <typename PriceT, typename OrderIdT, std::size_t PoolSize = (1u<<16)>
class OrderBook {
public:
    using OrderT = Order<PriceT, OrderIdT>;

#if HFT_USE_POOL
    using UPtr = std::unique_ptr<OrderT, PoolDeleter<OrderT, PoolSize>>;
#else
    using UPtr = std::unique_ptr<OrderT>;
#endif

    OrderBook()
        : m_buy(PriceDesc{}), m_sell(PriceAsc{}) {}

    // Insert order; returns non-owning pointer for immediate use
    OrderT* add(OrderIdT id, std::string sym, PriceT px, int qty, bool is_buy) {
#if HFT_USE_POOL
        auto* raw = m_pool.allocate(id, std::move(sym), px, qty, is_buy);
        UPtr uptr(raw, PoolDeleter<OrderT, PoolSize>{&m_pool});
#else
        UPtr uptr(new OrderT(id, std::move(sym), px, qty, is_buy));
#endif
        if (is_buy) {
            auto it = m_buy.emplace(px, std::move(uptr));
            return it->second.get();
        } else {
            auto it = m_sell.emplace(px, std::move(uptr));
            return it->second.get();
        }
    }

    bool cancel(OrderIdT id, bool is_buy) {
        auto& mm = is_buy ? m_buy : m_sell;
        for (auto it = mm.begin(); it != mm.end(); ++it) {
            if (it->second && it->second->id == id) {
                mm.erase(it);
                return true;
            }
        }
        return false;
    }

    // Best of book
    OrderT* best_bid() const { return m_buy.empty() ? nullptr : m_buy.begin()->second.get(); }
    OrderT* best_ask() const { return m_sell.empty() ? nullptr : m_sell.begin()->second.get(); }

    void pop_best_bid_if_empty() {
        if (!m_buy.empty() && m_buy.begin()->second->quantity <= 0) m_buy.erase(m_buy.begin());
    }
    void pop_best_ask_if_empty() {
        if (!m_sell.empty() && m_sell.begin()->second->quantity <= 0) m_sell.erase(m_sell.begin());
    }

    ~OrderBook() {
        // Ensure unique_ptr deleters run while pool (if any) is still alive
        m_buy.clear();
        m_sell.clear();
    }

private:
#if HFT_USE_POOL
    // Keep pool before maps so it is destroyed last (maps cleared in dtor anyway)
    ObjectPool<OrderT, PoolSize> m_pool;
#endif

    struct PriceDesc {
        bool operator()(const PriceT& a, const PriceT& b) const { return a > b; }
    };
    struct PriceAsc {
        bool operator()(const PriceT& a, const PriceT& b) const { return a < b; }
    };

    std::multimap<PriceT, UPtr, PriceDesc> m_buy;
    std::multimap<PriceT, UPtr, PriceAsc>  m_sell;
};
