#pragma once
#include <unordered_map>
#include <memory>
#include "Order.hpp"

enum class OrderState : uint8_t { New, PartiallyFilled, Filled, Canceled };

template <typename PriceT, typename OrderIdT>
class OrderManager {
public:
    using OrderT = Order<PriceT, OrderIdT>;
    using Ptr = std::shared_ptr<OrderT>;

    bool onNew(const Ptr& ord) {
        if (!ord) return false;
        m_orders[ord->id] = {ord, OrderState::New};
        return true;
    }
    bool onCancel(OrderIdT id) {
        auto it = m_orders.find(id);
        if (it == m_orders.end()) return false;
        it->second.state = OrderState::Canceled;
        return true;
    }
    void onFill(OrderIdT id, int filled_qty) {
        auto it = m_orders.find(id);
        if (it == m_orders.end()) return;
        if (filled_qty <= 0) return;
        it->second.ptr->quantity -= filled_qty;
        it->second.state = (it->second.ptr->quantity <= 0) ? OrderState::Filled : OrderState::PartiallyFilled;
    }
    OrderState state(OrderIdT id) const {
        auto it = m_orders.find(id);
        return (it == m_orders.end()) ? OrderState::Canceled : it->second.state;
    }

private:
    struct Node { Ptr ptr; OrderState state; };
    std::unordered_map<OrderIdT, Node> m_orders;
};
