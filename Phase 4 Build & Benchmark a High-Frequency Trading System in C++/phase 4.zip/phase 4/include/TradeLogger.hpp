#pragma once
#include <vector>
#include <fstream>
#include <string>
#include <utility>
#include <chrono>
#include "MatchingEngine.hpp"

// Toggle: HFT_DISABLE_LOGGER (default OFF)
// 0 -> normal batch logger (writes trades.csv)
// 1 -> no-op logger (useful to isolate I/O impact)
#ifndef HFT_DISABLE_LOGGER
#define HFT_DISABLE_LOGGER 0
#endif

#if HFT_DISABLE_LOGGER

class TradeLogger {
public:
    explicit TradeLogger(std::size_t = 0) {}
    void add(Trade) {}
    void flush() {}
    void write_file(const std::string&) {}
};

#else

class TradeLogger {
public:
    explicit TradeLogger(std::size_t reserve_n=1<<14) {
        m_trades.reserve(reserve_n);
        m_lines.reserve(reserve_n);
    }
    void add(Trade t) {
        m_trades.push_back(std::move(t));
        if (m_trades.size() >= m_batch_size) flush();
    }
    void flush() {
        if (m_trades.empty()) return;
        for (const auto& t : m_trades) {
            auto ns_recv = std::chrono::duration_cast<std::chrono::nanoseconds>(t.ts_recv.time_since_epoch()).count();
            auto ns_trade = std::chrono::duration_cast<std::chrono::nanoseconds>(t.ts_trade.time_since_epoch()).count();
            m_lines.emplace_back(std::to_string(t.trade_id) + "," + t.symbol + "," +
                                 std::to_string(t.price) + "," + std::to_string(t.quantity) + "," +
                                 std::to_string(ns_recv) + "," + std::to_string(ns_trade));
        }
        m_trades.clear();
    }
    void write_file(const std::string& path) {
        flush();
        std::ofstream ofs(path, std::ios::out | std::ios::binary);
        for (const auto& line : m_lines) {
            ofs.write(line.data(), static_cast<std::streamsize>(line.size()));
            ofs.put('\n');
        }
    }

private:
    std::vector<Trade> m_trades;
    std::vector<std::string> m_lines;
    const std::size_t m_batch_size = 4096;
};

#endif
