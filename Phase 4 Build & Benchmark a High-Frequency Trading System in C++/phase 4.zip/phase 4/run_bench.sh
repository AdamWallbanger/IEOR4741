#!/usr/bin/env bash
set -euo pipefail

# Batch benchmark driver for the HFT project (MSYS2 / Ninja)
# Usage: bash run_bench.sh [BUILD_DIR] [BUILD_TYPE]
# Env:   JOBS=<N> to set parallel jobs (optional)
# Example: JOBS=8 bash run_bench.sh build-bench Release

BUILD_DIR="${1:-build-bench}"
BUILD_TYPE="${2:-Release}"
GENERATOR="Ninja"

# Project root = this script's parent directory (works when script is in project root)
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_ROOT="${SCRIPT_DIR}"

RESULTS_DIR="${PROJECT_ROOT}/bench_results"
RESULTS_CSV="${RESULTS_DIR}/results.csv"
mkdir -p "${RESULTS_DIR}"

timestamp() { date +"%Y-%m-%d %H:%M:%S"; }

declare -a CASES=(
  "baseline|-DHFT_USE_POOL=ON  -DHFT_ALIGN_MD=ON  -DHFT_DISABLE_LOGGER=OFF"
  "pool_off|-DHFT_USE_POOL=OFF -DHFT_ALIGN_MD=ON  -DHFT_DISABLE_LOGGER=OFF"
  "align_off|-DHFT_USE_POOL=ON -DHFT_ALIGN_MD=OFF -DHFT_DISABLE_LOGGER=OFF"
  "logger_off|-DHFT_USE_POOL=ON -DHFT_ALIGN_MD=ON  -DHFT_DISABLE_LOGGER=ON"
)

# Header for CSV
if [[ ! -f "${RESULTS_CSV}" ]]; then
  echo "when,name,pool,align,logger_disabled,min_ns,p50_ns,p95_ns,p99_ns,max_ns,mean_ns,stddev_ns" > "${RESULTS_CSV}"
fi

extract() {
  local key="$1" line="$2"
  echo "${line}" | sed -E "s/.*${key}:\s*([0-9]+(\.[0-9]+)?).*/\1/"
}

build_with_ninja () {
  if [[ -n "${JOBS:-}" ]]; then
    ninja -C "${BUILD_DIR}" -j "${JOBS}"
  else
    ninja -C "${BUILD_DIR}"
  fi
}

run_case () {
  local name="$1"
  local flags="$2"
  echo ""
  echo "==== Running case: ${name} ===="
  echo "CMake flags: ${flags}"
  echo ""

  cmake -S "${PROJECT_ROOT}" -B "${BUILD_DIR}" -G "${GENERATOR}" -DCMAKE_BUILD_TYPE="${BUILD_TYPE}" ${flags}
  build_with_ninja

  local out rc
  set +e
  out="$( "${BUILD_DIR}/hft_app.exe" 2>&1 )"
  rc=$?
  set -e
  echo "${out}"

  if [[ $rc -ne 0 ]]; then
    echo "[WARN] Program exited with code ${rc}; skipping parse for ${name}"
    return
  fi

  local lat_line
  lat_line="$(echo "${out}" | grep -E 'Min:\s*[0-9]')" || true
  if [[ -z "${lat_line}" ]]; then
    echo "[WARN] Could not find latency line for ${name}; skipping parse."
    return
  fi

  local min p50 p95 p99 max mean stddev
  min="$(extract "Min" "${lat_line}")"
  p50="$(extract "P50" "${lat_line}")"
  p95="$(extract "P95" "${lat_line}")"
  p99="$(extract "P99" "${lat_line}")"
  max="$(extract "Max" "${lat_line}")"
  mean="$(extract "Mean" "${lat_line}")"
  stddev="$(extract "StdDev" "${lat_line}")"

  local pool="ON" align="ON" logger_disabled="OFF"
  [[ "${flags}" == *"HFT_USE_POOL=OFF"* ]] && pool="OFF"
  [[ "${flags}" == *"HFT_ALIGN_MD=OFF"* ]] && align="OFF"
  [[ "${flags}" == *"HFT_DISABLE_LOGGER=ON"* ]] && logger_disabled="ON"

  echo "$(timestamp),${name},${pool},${align},${logger_disabled},${min},${p50},${p95},${p99},${max},${mean},${stddev}" >> "${RESULTS_CSV}"
}

for row in "${CASES[@]}"; do
  IFS='|' read -r name flags <<< "${row}"
  run_case "${name}" "${flags}"
done

echo ""
echo "=== Done. Results written to: ${RESULTS_CSV} ==="
