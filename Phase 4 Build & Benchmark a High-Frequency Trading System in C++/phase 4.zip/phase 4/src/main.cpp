#include <iostream>
#include <vector>
#include <numeric>
#include <algorithm>
#include <memory>
#include <random>

#include "../include/MarketData.hpp"
#include "../include/Order.hpp"
#include "../include/OrderBook.hpp"
#include "../include/OrderManager.hpp"
#include "../include/MatchingEngine.hpp"
#include "../include/TradeLogger.hpp"
#include "../include/Timer.hpp"

using PriceT = double;
using OrderIdT = int;
using OB = OrderBook<PriceT, OrderIdT>;
using ME = MatchingEngine<PriceT, OrderIdT>;

static void analyzeLatencies(std::vector<long long>& latencies) {
    if (latencies.empty()) return;
    std::sort(latencies.begin(), latencies.end());
    auto min = latencies.front();
    auto max = latencies.back();
    double mean = std::accumulate(latencies.begin(), latencies.end(), 0.0) / latencies.size();

    auto pct = [&](double p) -> long long {
        size_t idx = static_cast<size_t>(p * (latencies.size()-1));
        return latencies[idx];
    };
    double variance = 0.0;
    for (auto l : latencies) variance += (l - mean) * (l - mean);
    double stddev = std::sqrt(variance / latencies.size());

    std::cout << "Tick-to-Trade Latency (ns)\n";
    std::cout << "Min: " << min << " | P50: " << pct(0.50)
              << " | P95: " << pct(0.95) << " | P99: " << pct(0.99)
              << " | Max: " << max << " | Mean: " << mean
              << " | StdDev: " << stddev << '\n';
}

int main() {
    constexpr int NUM_TICKS = 100000;           // adjust for load scaling
    constexpr int QTY_PER_ORDER = 100;

    OB orderBook;
    ME engine(orderBook);
    OrderManager<PriceT, OrderIdT> oms;
    TradeLogger logger(1<<15);
    MarketDataFeedSimulator mdf("AAPL", 150.0, 0.02);

    std::vector<long long> latencies;
    latencies.reserve(NUM_TICKS);

    std::mt19937 rng(123);
    std::uniform_int_distribution<int> sideDist(0, 1);
    std::uniform_int_distribution<int> pxJitter(-5, 5);

    for (int i = 0; i < NUM_TICKS; ++i) {
        // Simulate tick
        MarketData tick = mdf.next();

        // Start latency timing exactly on tick receipt
        auto tick_start = tick.timestamp;

        // Convert tick into an order intent
        bool is_buy = (sideDist(rng) == 0);
        double ref_px = is_buy ? tick.bid_price : tick.ask_price;
        double price = ref_px + 0.001 * pxJitter(rng);

        // Create shared_ptr for OMS while OrderBook stores unique_ptr (demonstrates mixed ownership).
        auto ord_sp = std::make_shared<Order<PriceT, OrderIdT>>(i, tick.symbol, price, QTY_PER_ORDER, is_buy);
        oms.onNew(ord_sp);

        // Insert into book via pool-backed unique_ptr
        auto* ob_ptr = orderBook.add(ord_sp->id, ord_sp->symbol, ord_sp->price, ord_sp->quantity, ord_sp->is_buy);
        (void)ob_ptr;

        // Attempt matching; trades carry both tick and trade timestamps
        auto trades = engine.match(tick_start);
        for (auto& t : trades) {
            logger.add(t);
        }

        // Compute tick-to-trade latency: if no trade, we still record the book processing latency
        long long latency_ns;
        if (!trades.empty()) {
            latency_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(trades.back().ts_trade - tick_start).count();
        } else {
            // No trade -> measure until after match attempt
            latency_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now() - tick_start).count();
        }
        latencies.push_back(latency_ns);
    }

    logger.write_file("trades.csv");
    analyzeLatencies(latencies);

    std::cout << "Trades written to trades.csv (" << "batch logged).\n";
    return 0;
}
