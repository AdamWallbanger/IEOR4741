#include <gtest/gtest.h>
#include <vector>
#include <algorithm>
#include <numeric>
#include "../include/Timer.hpp"

TEST(LatencyMath, Percentiles) {
    std::vector<long long> v{5,2,9,1,3,7,6,4,8};
    std::sort(v.begin(), v.end());
    auto p50 = v[static_cast<size_t>(0.5 * (v.size()-1))];
    auto p99 = v[static_cast<size_t>(0.99 * (v.size()-1))];
    EXPECT_EQ(p50, 5);
    EXPECT_EQ(p99, 9);
}

TEST(Timer, Monotonic) {
    Timer t; t.start();
    auto a = t.stop_ns();
    auto b = t.stop_ns();
    EXPECT_GE(b, a);
}
