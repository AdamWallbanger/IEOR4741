# HFT Tick Processing: CRTP vs Virtual Dispatch — Microbenchmark

## Environment
- **OS:** Windows (MSYS2 toolchain)
- **Compiler:** g++ (MSYS2) 14.2.0
- **CPU:** 12th Gen Intel(R) Core(TM) i9-12900H — 14 cores / 20 threads, MaxClock 2.5 GHz
- **Build flags:** `-O3 -DNDEBUG -march=native -fno-exceptions -fno-rtti`

> Note: Linux `perf` is not available on native Windows. If counters are required, run under WSL2 or Linux (see below).

## Build
```bash
g++ -std=c++20 -O3 -DNDEBUG -march=native -fno-exceptions -fno-rtti     -Iinclude src/main.cpp -o hft.exe
```

## Run
```bash
hft.exe 10000000 1
```
Arguments:
- `N` (default `10000000`): number of synthetic ticks to process
- `iters` (default `1`): repeat passes over the same tick stream

The program prints wall time for each variant and a summary with **ns/tick** and **ticks/sec**.

## Optional: pin to one core on Windows
Pinning reduces scheduler noise; also set Power Plan to **High performance**.
```cmd
REM Run 20M ticks on logical CPU 0
start /affinity 1 hft.exe 20000000 1
```

## Perf counters (optional; Linux/WSL2)
If you need hardware counters:
```bash
# Install tools (Ubuntu)
sudo apt update
sudo apt install -y build-essential linux-tools-common linux-tools-generic

# Build (Linux binary, no .exe)
g++ -std=c++20 -O3 -DNDEBUG -march=native -fno-exceptions -fno-rtti     -Iinclude src/main.cpp -o hft

# Pin to a single core and collect counters for the whole run
taskset -c 0 perf stat -e cycles,instructions,branches,branch-misses ./hft 20000000 1
```

> Some WSL2 versions limit PMU access. If events are unsupported, document the limitation in the report.

## Project Layout
```
include/
  market_data.hpp
  utils.hpp
  strategy_virtual.hpp
  strategy_crtp.hpp
  strategy_aggregators.hpp   # (extensions, optional)
  market_data_soa.hpp        # (extensions, optional)
src/
  main.cpp
```

## Variants (base assignment)
- **free function**: direct call (control)
- **virtual**: runtime polymorphism (`IStrategy::on_tick`)
- **CRTP**: static polymorphism (`StrategyBase<Derived>::on_tick`)

## What the program measures
- Wall time per variant
- Derived metrics: **ns/tick** and **ticks/sec**
- (Optional on Linux) Hardware counters via `perf stat`:
  - `cycles`, `instructions`, `branches`, `branch-misses`

## Notes
- Results vary by CPU, compiler, and flags. Keep hot code small and avoid allocations in the hot path.
- For strictly comparable runs, pin to one core and avoid thermal throttling.
- See `REPORT.md` for analysis and your measured results.
